

def checkValErr(a, b):
	try:
		a = float(a)
		b = float(b)
	except ValueError:
		print("The calculator only works on numbers!")
		a = 0
		b = 0
	return a, b #multiple return, can use array or tuplr for this

def add(a, b):
	a, b = checkValErr(a, b) #mutiple assignment, can use array or tuple for this
	return round(a + b, 4) #rounds off to 4 sig digits  

def sub(a, b):
	a, b = checkValErr(a, b) #mutiple assignment, can use array or tuple for this
	return round(a - b, 4) #rounds off to 4 sig digits  

def mul(a, b):
	a, b = checkValErr(a, b) #mutiple assignment, can use array or tuple for this
	return round(a * b, 4) #rounds off to 4 sig digits

def div(a, b):
	a, b = checkValErr(a, b) #mutiple assignment, can use array or tuple for this

	if b == 0:
		print("The calculator cannot divide by 0")
		return 0
	return round(a / b, 4) #rounds off to 4 sig digits

def calc():
	while (True):
		print("\nCalculator\n")
		a = input("\nPick a number\n> ")
		op = input("\nPick an operation:\n1. Add\n2. Subtract\n3. Multiply\n4. Divide\n5. Close\n> ")
		try:
			op = int(op)
		except ValueError:
			print("\nPlease select an operation by entering a number into the menu.\n")
			continue
		if not (int(op) > 0 and int(op) < 6):
			print("\nPlease select an operation from the menu\n")
			continue
		if not op == 5:
			b = input("\nPick a number\n> ")

		#do op
		if(op == 1):
			print(add(a, b))
		if(op == 2):
			print(sub(a, b))
		if(op == 3):
			print(mul(a, b))
		if(op == 4):
			print(div(a, b))
		if(op == 5):
			print("Goodbye")
			return

		print()
calc()