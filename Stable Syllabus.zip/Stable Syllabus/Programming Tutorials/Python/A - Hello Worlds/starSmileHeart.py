#https://docs.python.org/3/library/turtle.html
from turtle import *

#just some init
screensize(400, 400)
bgcolor("lavender")
pensize(10)
color("blue")
delay = 7



#set start location of star
ht()
up()
goto(-300, 75)
down()
st()

#draw star
fillcolor('blue')
begin_fill()
angle = 36
side = 600
for i in range(5):
    forward(side)
    right(180-angle)
    print(pos())

end_fill()

ht()
up()
goto(0, -20)
down()
st()
pensize(250)
forward(1)



ht()
right(360 * delay)

#smiley init
reset()
bgcolor("lavender")
pensize(10)
color("purple")
fillcolor('purple')




#start location of smiley
ht()
up()
goto(0,280)
down()
st()

#draw circle
begin_fill()
angle = 1
side = 4.5
for i in range(360):
    forward(side)
    right(angle)
    #print(pos())
end_fill()
color("lavender")

#eyes
pensize(70)
ht()
up()
goto(-100,130)
down()
st()
forward(1)

ht()
up()
goto(100,130)
down()
st()
forward(1)

pensize(30)
ht()
up()
goto(-100,-50)
left(270)
down()
st()
#draw smile
angle = 2
side = 3.5
for i in range(int(180 / angle)):
    forward(side)
    left(angle)
    #print(pos())


ht()
right(360 * delay)


reset()
bgcolor("lavender")
pensize(10)
color("red")
lengt = 2.5

ht()
up()
goto(0,-250)
down()
st()

#start location of heart
fillcolor('red')
begin_fill()
left(140)
forward(100 * lengt + 1)
for i in range(200):

    right(1)
    forward(lengt)
left(120)
for i in range(200):

    right(1)
    forward(lengt)
goto(0,-250)
end_fill()
ht()
right(360 * delay)
bye()
