import random
#This is intended to teach stacks
#The card game I'm going with is WAR, because it is simple, and suits do not matter.
#I'm also changing the rules a bit so games are faster:
	#1. Player one and two are delt half the deck each
	#2. Both players play a card and the higher card wins a point (Discards go in pile; get popped off the stack.)
	#3. When the played cards match rank, the higher suit wins. Low to high: clubs, diamonds, hearts, spades 
	#4. Aces are high or low. Ace beats King and 2 beats Ace.
	#5. When no cards are left to play, the higher scoring player wins
	#6. No jokers

def getDeck():
	deck = Stack()
	suits = ["clubs", "diamonds", "hearts", "spades"]
	for suit in suits:
		for i in range(1, 14): # Jack is 11, Queen is 12, King is 13,
			card = Card(i, suit)
			deck.push(card)
			#print(i, suit)
	deck.shuffle()
	return deck



class Stack: #you can just use an array for this if you prefer.
	stack = []
	def getSize(self):
		return len(self.stack)
	def push(self, card):
		self.stack.append(card)
	def pop(self):
		#print(len(self.stack))
		card = self.stack[len(self.stack) - 1]
		self.stack = truncate(self.stack)
		return card
	def isEmpty(self):
		return len(self.stack) == 0
	#used to shuffle the deck	
	def shuffle(self):
		#print(self.stack)
		#print(len(self.stack) -1)
	#produces shuffled list
		out = []


		while(not self.isEmpty()):
			rr = random.randint(0, len(self.stack) - 1)
			#print(r)
			out.append(self.stack[rr])
			self.stack.remove(self.stack[rr])
		self.stack =  out

class Card: #functionally just a tuple of length 2
	def __init__(self, rank, suit):
		self.rank = rank
		self.suit = suit

	def getRank(self):
		return self.rank
	def getSuit(self):
		return self.suit

#does a stack pop
def truncate(arr):
	i = 0
	out = []
	while i < len(arr) -1:
		out.append(arr[i])
		i = i + 1
	return out

def war(a, b):
	print("\nWar!\n")
	suits = ["clubs", "diamonds", "hearts", "spades"]

	#whoever gets found first loses the point
	for s in suits:
		if s == a.getSuit():
			print("The point goes to Player 2\n")
			return - 1
		if s == b.getSuit():
			print("The point goes to Player 1\n")
			return 1



def game():
	print("\nWar!\n")
	deck = getDeck()
	p1 = Stack
	p2 = Stack
	score = 0 #score can just be an integer; player 1 adds, player 2 subtracts

	#deal
	while not deck.isEmpty():
		
		
		card1 = deck.pop()
		p1.push(p1, card1)
		if not deck.isEmpty():
			card2 = deck.pop()
			p2.push(p2, card2)

	cardRanks = ["", "Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"]

	while not (p1.isEmpty(p1) or p2.isEmpty(p2)):
		card1 = p1.pop(p1)
		card2 = p2.pop(p2)

		print("Player 1 plays", cardRanks[card1.getRank()], "of", card1.getSuit().title())
		print("Player 2 plays", cardRanks[card2.getRank()], "of", card2.getSuit().title())

		if card1.getRank() > card2.getRank() or (card1.getRank() == 1 and card2.getRank() == 13): #ace beats king
			print("The point goes to Player 1\n")
			score += 1
		if card1.getRank() < card2.getRank() or (card2.getRank() == 1 and card1.getRank() == 13):
			print("The point goes to Player 2\n")
			score -= 1
		if card1.getRank() == card2.getRank():
			score += war(card1, card2)
	if score > 0:
		print("Player 1 wins by", score)
	if score < 0:
		print("Player 2 wins by", score * -1)
	if score == 0:
		print("Draw!")

	print("Game Over\n\n")




game()
