import random
def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1
                
        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out


def heapify(arr, n, i):
    print(arr, n, i)

    # Initialize largest as root
    largest = i
    # left child index = 2*i + 1
    left = 2 * i + 1
    # right child index = 2*i + 2
    right = 2 * i + 2

    if left < n and arr[left] > arr[largest]:
        largest = left

    if right < n and arr[right] > arr[largest]:
        largest = right

    # If largest is not root
    if largest != i:

        #swap
        temp = arr[i] 
        arr[i] = arr[largest]
        arr[largest] = temp

        # Recursively heapify all subheaps
        heapify(arr, n, largest)
    return arr


 
def heapSort(arr):

    #The key here is that every unsorted value will eventually be the root (index 0), and then get sorted
    #That is why the max is used. This took me several hours to understand because no tutorial bothers to explain that.
    n = len(arr)

    # Build heap

    print("\nBuilding Heap:")
    halfwayPoint = (n // 2 - 1)
    for i in range(halfwayPoint, -1, -1):
        arr = heapify(arr, n, i)
    print("\nHeap:")
    print(arr)
    print("\nBegin Sort:")
    print(arr)
        

    for i in range(n - 1, 0, -1):
        # Move current root to end
        temp = arr[0]
        arr[0] = arr[i]
        arr[i] = temp

        # Call max heapify on the reduced heap
        heapify(arr, i, 0)
    return arr

if __name__ == "__main__":
    arr = shufArr(10)
    print(arr)
    print(heapSort(arr))

#Credit where it is due...
#https://www.geeksforgeeks.org/dsa/heap-sort/