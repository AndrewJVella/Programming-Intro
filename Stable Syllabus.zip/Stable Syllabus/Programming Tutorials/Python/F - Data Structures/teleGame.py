import random
#This is a game of telephone. It is also the only way I could think to make a queue structure interesting.
#The idea is that a nonsense word gets permuted, or switched randomly, as it gets passed along the queue of players.
#Players get three numbers between 0 and 10, that describe how silly, inaccurate, or. forgetful they are

WORDS = []
NAMES = []

class Player:
	def __init__(self, name):
		self.name = name
		self.max = random.randint(10, 100)
		self.weight = random.randint(1, self.max)


	def getName(self):
		return self.name
	def gimme(self, word):
			dice = random.randint(self.weight, self.max)
			if dice == self.max:
				self.name = "(Silly) " + self.name 
				return getWord() #Player ignores the given word 

			#create a char array of every letter in alphabet
			alpha = []
			for a in range(97, 123):
				alpha.append(chr(a))

			#create a char array for every char in the word
			charArr = []
			for c in word:
				charArr.append(c)
			word = "" #word will be replaced

			mutates = dice % (len(charArr) // 2)
			while mutates > 0:
				#randomly switch out letters in the word
				charArr[random.randint(0, len(charArr) -1)] = alpha[random.randint(0, len(alpha) -1)]
				mutates = mutates - 1
			for c in charArr:
				word = word + c #replace word with mutation
			return word

class Queue:
	q = []
	def __init__(self):
		pass
	def enqueue(self, member):
		self.q.append(member)
	def dequeue(self):
		self.q.remove(self.q[0])
	def get(self):
		if len(self.q) > 0:
			return self.q[0]
	def isEmpty(self):
		return len(self.q) == 0 




def getWord():
	global WORDS
	return WORDS[random.randint(0, len(WORDS)-1)]
def getName():
	global NAMES
	name = NAMES[random.randint(0, len(NAMES)-1)].strip()
	if name == "":
		return "Nobody"
	return name



def initWords():
	#A game of telephone needs a bunch of silly words and names. 

	with open("teleWords.txt", "r") as file:
		content = file.read()
		file.close()
	sillyWords = content.split("\n")

	global WORDS
	global NAMES

	for w in sillyWords:
		WORDS.append(w.strip())

	for n in NAMES:
		if random.randint(1, 6) == 1:
			WORDS.append(n.strip())



def initNames():
	#A game of telephone needs a bunch of silly words and names. 

	with open("teleNames.txt", "r") as file:
		content = file.read()
		file.close()
	names = content.split("\n")

	global NAMES

	for n in names:
		NAMES.append(n.title().strip())


def main(n):
	initNames()
	initWords()



	startWord = getWord()
	word = startWord
	teleQ = Queue()

	

	for p in range(n):
		play = Player(getName())
		teleQ.enqueue(play) #Queue of players

	print("\n-The word is", "\""  + word.lower() + "\"-\n")

	while not teleQ.isEmpty():
		word = teleQ.get().gimme(word)
		print(teleQ.get().getName(), "says the word is", str("\""  + word.lower() + "\"").rjust(30 - len(teleQ.get().getName())))
		teleQ.dequeue()
	if startWord != word:
		print("\nThe word is \"" + startWord.lower() +  "\" but we got \"" + word.lower() +  "\"!")

	if startWord == word:
		print("\nThe word is \"" + word.lower() +  "\"!")

main(10)











