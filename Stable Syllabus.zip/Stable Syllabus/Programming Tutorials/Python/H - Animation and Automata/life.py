from turtle import *
import math
import random
import copy
import time



#I would like to be able to pass a array of live cells into the life() function, using a spreadsheet convention
# ["A1", "B2"] and others..

#This program renders cells on an x, y grid.
#Each cell can have an integer state denoted by a color.

#Cells are named according to spreadsheet convention (but still counting from zero).
#Cells are denoted by col and row.
#cols are denoted by (Latin) letter and rows are denoted by number.
#The cell in the north west corner is A0. 
#A1 is south of A0. B0 is east of A0.
#col Z is followed by col AA, which is followed by col AB.
#So cells can continue to infinity 

def texter(text, size = 16):
	size = int(size)
	write(text, align="center", font=("Helvetica", size, "bold"))

def indexToCol(i):
	return chr(i + 65) #A is 65
	
def printGrid(grid):
	for row in grid:
		print(row)

def init(x = 1, y = 1):
	#just some init
	screensize(x,y)
	bgcolor("black")
	#shape("turtle")
	ht()
	tracer(False)
	setundobuffer(None)

def randGrid(x, y):
	arr = []

	for i in range (y):
		row = []
		for j in range (x):
			row.append(random.randint(0,1))
		arr.append(row)
	return arr

def testRender(n):
	for i in range(1, 20):
		clear()
		render(randGrid(i, i), n)
	exitonclick()


def isDead(arr):
	for i in arr:
		for j in i:
			if j > 0:
				return False
	return True

def setCellbygridIndex(row, col, grid):
	col = col % len(grid[0])
	row = row % len(grid)
	grid[row][col] = 1

	return grid

def getCellbygridIndex(row, col, grid):
	col = col % len(grid[0])
	row = row % len(grid)
	return grid[row][col]

def mapCellToArr(inps, grid):
	#converts "A1" to grid[0][0] and the like
	#print(inps)
	for cell in inps:
		cell = cell.upper()
		letter = ""
		number = ""

		for char in cell:
			if char.isdigit():
				number += char
			else:
				letter += char
		#print(cell, letter, number)
		row = int(number)
		col = 0

		letter = letter[::-1] #reverse string for parsing

		i = 0
		while i < len(letter):
			col += (ord(letter[i]) - 65) ** (i + 1) #A -> 1, B -> 2, etc; i allows for handling beyond Z, as AA, AB, etc
			#print("col:", col)
			i = i + 1
		#print(col, row)
		grid = setCellbygridIndex(row, col, grid)
	#printGrid(grid)
	return grid

def render(arr, size, buffer =2): #assume the array encodes cells on an x by y grid of cells
	clear() #the screen needs to be cleared for each render, to prevent slowdowns
	if len(arr) < 4 or len(arr) > (size//2):
		#do not render
		exit()
		return

	area = len(arr)
	width = len(arr[0])
	height = len(arr)
	cellSize = size / width
	penSize = cellSize - (buffer)
	colors = ["SeaGreen", "lavender"]
	pensize(penSize)
	i = 0
	up()
	startX = - size // 2
	startY = size // 2

	#printing grid indicators to screen 
	color(colors[0])
	for i in range(width):
		if i % 5 == 0:
			goto(startX + (cellSize * i), startY + cellSize // 2)
			texter(indexToCol(i), cellSize / 1.5)
	for i in range(height):
		if i % 5 == 0:
			goto(startX - cellSize, startY - (cellSize * (i + 1)) + cellSize // 2 )  
			texter(i, cellSize / 1.5)


	#rendering the grid

	goto(startX, startY)

	row = 0
	col = 0

	while row < len(arr):
		while col < len(arr[row]): 		
			down()
			try:
				color(colors[arr[row][col]])
			except IndexError:
				color("black")
			forward(1)
			forward(-1)
			up()
			setx(xcor() + cellSize)
			col = col + 1
			
		sety(ycor() - cellSize)
		setx(startX)
		row = row + 1
		col = 0
	update()

def nextLife(grid): #computes next generation of Life; takes a grid as a 2d array
	col = 0
	row = 0
	out = []

	while row < len(grid):
		outRow = []
		while col < len(grid[row]):
			#get each neighbor of current cell
			north = getCellbygridIndex(row - 1, col, grid)
			south = getCellbygridIndex(row + 1, col, grid)
			east = getCellbygridIndex(row, col + 1, grid)
			west = getCellbygridIndex(row, col - 1, grid)
			northEast = getCellbygridIndex(row - 1, col + 1, grid)
			nortWest = getCellbygridIndex(row - 1, col - 1, grid)
			southEast = getCellbygridIndex(row + 1, col + 1, grid)
			southWest = getCellbygridIndex(row + 1, col - 1, grid)

			neighborSum = north + south + east + west + northEast + nortWest + southEast + southWest
			alive = None
			if neighborSum < 2 or neighborSum > 3:
				alive = False #living cell dies
			if neighborSum == 3:
				alive = True #a cell is (re)born
			if neighborSum == 2:
				alive = (grid[row][col] == 1)  # exactly two living neighbors leaves cell unchanged
		
			if alive:
				outRow.append(1)
			if not alive:
				outRow.append(0) 

			col = col+1
		row = row + 1
		col = 0

		out.append(outRow)
	return out

def life(inps= ["B2", "C3", "D1", "D2", "D3"], n = -1, gridWidth = 26, gridHeight = 26, screenWidth = 600, screenHeight = 450,  delay = .03):
	#Default: put a glider on the diagonal of a 26 by 26 grid on a screen of 600 by 450 pixels, and run for an unlimited number of generations, with a delay of 1/30th of a second.

	startEndDelay = 1
	init(screenWidth, screenHeight)
	grid = []
	row = []

	for i in range(gridWidth):
		row.append(0)
	for i in range(gridHeight):
		grid.append(copy.deepcopy(row)) #need to pass by value here

	grid = mapCellToArr(inps, grid)

	render(grid, (screenWidth + screenHeight) / 2)
	time.sleep(startEndDelay)

	i = 0
	while not i == n: #if n is -1 or less, continue until grid dies
		grid = nextLife(grid)
		render(grid, (screenWidth + screenHeight) / 2)
		if isDead(grid):
			time.sleep(startEndDelay)
			return
		i = i + 1
		time.sleep(delay)
	time.sleep(startEndDelay)
	return

if __name__ == '__main__':
	life()

