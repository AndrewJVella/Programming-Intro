from turtle import *
import copy
import random
#SO the turtle could be the ant.
#but it needs to know what color pixel it is on.
#I guess the answer is to map every pixel on the screen to a 2d array, and have the turtle update that
#There is no way to get the pixel color directly with the turtle. Need to use tkinter for that.

#Also good to specifiy a unit in pixels. 
#The turtle moves in these units and the grid is divded into these units
#The turtle calls update after each movement

#Using a 2d array for the grid
#The center of the turtle is (0,0), but on the grid the north west corner is (0,0) 
#The postion of the turle is offset by half the height and width of the screen.

#Turtle can start in the center
#At a black square, turn 90° clockwise, flip the color of the square, move forward one unit
#At a white square, turn 90° counter-clockwise, flip the color of the square, move forward one unit

def printGrid(grid):
	for row in grid:
		print(row)
def makeGrid(gridWidth = 1, gridHeight = 1):
	grid = []
	row = []

	for i in range(gridWidth):
		row.append(0)
	for i in range(gridHeight):
		grid.append(copy.deepcopy(row)) #need to pass by value here
	return grid

#I tried using the renderer from life, it was terrifying. 
def ant(x = 400, y= 400, step = 3, direct = -1):
	COLORS = ["fireBrick2","Sienna2", "Goldenrod2", "SeaGreen2", "SteelBlue2", "SlateBlue2", "MediumOrchid2"]



	#just some init
	screensize(x,y)
	bgcolor("black")
	shape("turtle")
	ht()
	tracer(False)
	coloring = COLORS[random.randint(0, len(COLORS) - 1)]
	grid = makeGrid(x, y)
	#printGrid(grid)
	goto(0,0)

	if direct < 0:
		direct = random.randint(1, 4)

	left(90 * direct)


	offsetW = (x // (2 * step))
	offsetH = (y // (2 * step))
	


	#At a black square, turn 90° clockwise, flip the color of the square, move forward one unit
	#At a white square, turn 90° counter-clockwise, flip the color of the square, move forward one unit
	i = 0

	while (True):
		try:
			if i > 1000: #this prevents slowdown. Data is still on the grid, so steps are not lost.
				i = 0
				clear()

			turtX = int(xcor())
			turtY = int(ycor())
			if grid[turtX + offsetW][turtY + offsetH] == 0: #black
				grid[turtX + offsetW][turtY + offsetH] = 1 #turn white
				color(coloring)
				pensize(int(step))
				down()
				forward(1)
				forward(-1)
				up()
				right(90)
				forward(step)
				update()
				i = i + 1
				continue
			if grid[turtX + offsetW][turtY + offsetH] == 1: #white
				grid[turtX + offsetW][turtY + offsetH] = 0 #turn black
				color("black")
				pensize(int(step))
				down()
				forward(1)
				forward(-1)
				up()
				left(90)
				forward(step)
				update()
				i = i + 1
				continue
		except IndexError:
			#went off screen, reset
			clear()
			direct = random.randint(1, 4)
			left(90 * direct)
			coloring = COLORS[random.randint(0, len(COLORS) - 1)] 
			grid = makeGrid(x, y)
			goto(0, 0)

ant()


