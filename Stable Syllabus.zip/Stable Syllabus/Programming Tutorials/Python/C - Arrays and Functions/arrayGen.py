import random
def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1
                
        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out

print(ordArr(10))
print(shufArr(10))
print(revArr(10))