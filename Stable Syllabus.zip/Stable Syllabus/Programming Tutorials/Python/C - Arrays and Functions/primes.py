def primes(n):
        primes = [2]
        for i in range(3, n + 1):
                isPrime = True
                #note the use of linear search
                for p in primes:
                        if (i % p == 0):
                                isPrime = False
                if isPrime:
                        primes.append(i)
        return primes

n = 100
print("List of primes to", n)
print(primes(n))
