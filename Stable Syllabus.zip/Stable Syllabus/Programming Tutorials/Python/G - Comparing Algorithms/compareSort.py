
import random
import copy
import time
import tabulate
#GLOBALS
SORTS = ["Bubble", "Select", "Insert", "Merge", "Heap", "Quick"] #"Tim (8)", "Tim (64)"
COMPARES = 0
CAPTURES = []
VERIFIED = False



#SORT MANAGER

def reset():
        global COMPARES
        COMPARES = 0

def compare(n = 1):
        global COMPARES
        COMPARES += n

def verify(arr):

        for i in range(0, len(arr) -1):
                if (arr[i] > arr[i+1]):
                        return False
        return True

def getTime(start, end):
        time = end - start
        return round((time / 1000))
        #You may be wondering, why have I not included a unit of time?
        #This sould return millis, but from what I can tell, this is actually tenths of a milli
        #Time calculations may be machine dependent. Idk.


def capture(name, time):
        global CAPTURES
        CAPTURES.append((name, COMPARES, time)) #appending a tuple of the sort, number of COMPARES, time passed, and verification 

def doSort(name, unSortarr, veri = False): #if veri is on, verify the sort works, instead of checking performance


        #Deep copy needs to be used here.
        #Each sort runs on a copy of the unsorted array. 
        #Without deep copy, each sort would modify the same array.
        arr = copy.deepcopy(unSortarr)

        #reset  
        reset()     
        global SORTS
        global TIME
        #do sort
        sortedArr = []
        if name == SORTS[0]:
                if veri:
                        return verify(bubbleSort(arr))

                start = time.perf_counter_ns()
                bubbleSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        if name == SORTS[1]:
                if veri:
                        return verify(selectionSort(arr))

                start = time.perf_counter_ns()
                selectionSort(arr) 
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))

                return
        if name == SORTS[2]:
                if veri:
                        return verify(insertionSort(arr))

                start = time.perf_counter_ns()
                insertionSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        if name == SORTS[3]:
                if veri:
                        return verify(mergeSort(arr))

                start = time.perf_counter_ns()
                mergeSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return

        if name == SORTS[4]:
                if veri:
                        return verify(heapSort(arr))

                start = time.perf_counter_ns()
                heapSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        if name == SORTS[5]:
                if veri:
                        return verify(quickSort(arr))

                start = time.perf_counter_ns()
                quickSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        else:   
                print()
                print(name, "Sort is not implemented.")
                print("Implemented sorts:", end = " ")
                for i in SORTS:
                        print("\"" + i + "\"", end = " ")
                print("\n")
                return


def sortComparator(arr, sorts = [], unsortedPrint = True):
        #the sorts parameter can be used to omit sorts, such as bubble sort on a large list
        global CAPTURES

        if sorts == []:
                global SORTS
                sorts = SORTS

        CAPTURES = []

        for sort in sorts: #a deep copy is used
                doSort(sort, arr)

        markdown_table =tabulate.tabulate(CAPTURES, ["Sort", "Compares", "Time"], tablefmt="pipe", stralign="left")
        return (markdown_table)


#AUXILARY FUNCTIONS

def partition(arr, low, high):
        pivot = arr[high] #largest index is our partition
        i = low -1
        for j in range(low, high):
                if arr[j] < pivot:
                        i += 1
                        doSwap(arr, i, j)
                        compare()
        doSwap(arr, i + 1, high)
        compare()
        return i + 1


def heapify(arr, n, i):
    
    # Initialize largest as root
    largest = i
    # left child index = 2*i + 1
    left = 2 * i + 1
    # right child index = 2*i + 2
    right = 2 * i + 2

    if left < n and arr[left] > arr[largest]:
        largest = left

    if right < n and arr[right] > arr[largest]:
        largest = right

    # If largest is not root
    if largest != i:

        #swap
        temp = arr[i] 
        arr[i] = arr[largest]
        arr[largest] = temp

        # Recursively heapify all subheaps
        heapify(arr, n, largest)
    compare()
    return arr

def getRunSize(arr):
        #Used for Tim sort if no run is specified
        run = 64
        while run > (len(arr) // 2):
                run = run / 2
        return run

def merge(arrA, arrB):
    #if arrays are different lengths, a is always the shorter one
    if len(arrA) > len(arrB):
            temp = arrB
            arrB = arrA
            arrA = temp

    #base cases
    if len(arrB) == 0:
        return arrA
    if len(arrA) == 0:
        return arrB

    #Merge sort is a bit of a paradox.
    #You need to merge lists to sort them,
    #and you need to sort lists to merge them.
    #This is the "paradox resolver" and (despite the fact this is a solved problem) this took like two hours
    else:
        arrA = mergeSort(arrA)
        arrB = mergeSort(arrB)
        merged = []
        while len(arrA) > 0 and len(arrB) > 0:
           # print(arrA, arrB, merged)
            if arrA[0] < arrB[0]:
                merged.append(arrA[0])
                arrA.remove(arrA[0])
                continue
            if arrB[0] < arrA[0]:
                merged.append(arrB[0])
                arrB.remove(arrB[0])
                continue
            if arrB[0] == arrA[0]:
                merged.append(arrA[0])
                arrA.remove(arrA[0])
                merged.append(arrB[0])
                arrB.remove(arrB[0])
                continue

        if len(arrA) > 0:
            for a in arrA:
                merged.append(a)
        if len(arrB) > 0:
            for b in arrB:
                merged.append(b)
   # print(merged)
    compare(len(merged))
    return merged

#SORTS
 
def heapSort(arr):

    #The key here is that every unsorted value will eventually be the root (index 0), and then get sorted
    #That is why the max is used. This took me several hours to understand because no tutorial bothers to explain that.
    n = len(arr)

    # Build heap

    halfwayPoint = (n // 2 - 1)
    for i in range(halfwayPoint, -1, -1):
        arr = heapify(arr, n, i)
        

    for i in range(n - 1, 0, -1):
        # Move current root to end
        temp = arr[0]
        arr[0] = arr[i]
        arr[i] = temp
        compare()

        # Call max heapify on the reduced heap
        heapify(arr, i, 0)
    return arr


#This is an out-of-place merge sort, for visualization (or, it will be...)
def mergeSort(arr):
        #base cases
        if len(arr) == 2:
            return merge([arr[0]], [arr[1]])
        if len(arr) == 1:
            return arr
        #split the array into left and right
        start = 0
        end = len(arr) -1
        pivot = (start + end) // 2 #get the middle index of the list by calculating the average
        left = []
        right = []

        #get left side
        for i in range(0, pivot + 1):
            left.append(arr[i])
        #get right side
        for i in range(pivot + 1,len(arr)):
            right.append(arr[i])
        return merge(left, right)

def bubbleSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        
        #given arr is an array
        n = len(arr)
        i = 0
        x = 1

        while(x < (n + 1)):
                while(i < n - x):
                        swapCheck(arr, i, i+1)
                        i = i +1
                i =0
                x = x+1
        return arr

def selectionSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        maxIndex = len(arr) - 1
        maxValue = -1

        while(maxIndex > 0):
                i = 0
                indexUnsortedMax = -1
                #get max unsorted value
                while (i <= maxIndex):  #this inequality was diabolical. It took an hour to notice I had written '<', not '<='. 
                        compare()
                        if arr[i] > maxValue:
                                maxValue = arr[i]
                                indexUnsortedMax = i
                        i = i + 1
                if indexUnsortedMax > - 1:
                        doSwap(arr, maxIndex, indexUnsortedMax)
                        maxValue = -1
                i = 0
                maxIndex = maxIndex - 1
        return arr
                
def insertionSort(arr): 
        if len(arr) < 2: #already sorted case
                return arr
        for i in range (0, len(arr) -1):
                j = i + 1
                while j > 0:
                        swapCheck(arr, j-1, j)
                        j = j - 1
        return arr

def quickSort(arr, low = 0, high = -1):
        #whole array by default
        if high == -1:
                high = len(arr) -1

        if (low < high):
                partitionIndex = partition(arr, low, high)
                #recursively sort either side of the partition
                quickSort(arr, low, partitionIndex - 1)
                quickSort(arr, partitionIndex + 1, high)
        return arr

#FIXME Tim Sort returns, 0 comparsions and extremely low times in some cases that are not sorted. IDK why.
def timSort(arr, run = 32):
    #uses insertion sort on runs, and merges them together. A run is a contiguous segment of the array, of length "run"
    out = []
    runCount = len(arr) // run
    runCounter = 0 #counts from 0 to runCount
    r1 = 0
    r2 = 0
    r3 = 0

    #sort and merge runs
    while runCounter < runCount:
        r1 = run * runCounter
        r2 = r1 + (run) #slices exclude the max
        r3 = len(arr)
        sortme = arr[r1:r2] #this is a slice: array[a:b] is an array of items from array[a] to array[b-1]
        out = merge(out, insertionSort(sortme))
        runCounter += 1

    r1 = run * runCounter
    sortme = arr[r1:r3]
    out = merge(out, insertionSort(arr[r1:r3]))

    return out


#SWAP FUNCTIONS

#this is a conditional swap, used to sort elements
def swapCheck(arr, a, b):
        if (arr[a] > arr[b]):
                arr = doSwap(arr, a, b)
        compare()
        return arr

#this is an unconditional swap, used to count COMPARES
def doSwap(arr, a, b):
        temp = arr[a]
        arr[a] = arr[b]
        arr[b] = temp
        compare()
        return arr

#ARRAY GENERATOR FUNCTIONS

def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                out.append(a[r])
                a.remove(a[r])
        return out

def test(n):
        global SORTS
        global VERIFIED
        
        if not VERIFIED:
                print("Verifying Sorts")

                for sort in SORTS:
                        if not doSort(sort, revArr(4), True):
                                print (sort, "Sort falied. Debug is needed.")
                                return
                VERIFIED = True
                print("Verified!\n")

        print("Sorts on arrays of size " + str(n) +":")
        print("Sorted, Reversed, and Shuffled")
        print()
        print(sortComparator(ordArr(n)))
        print()
        print(sortComparator(revArr(n)))
        print()
        print(sortComparator(shufArr(n)))
        print()


#MAIN
if __name__ == '__main__':
        test(150)

        