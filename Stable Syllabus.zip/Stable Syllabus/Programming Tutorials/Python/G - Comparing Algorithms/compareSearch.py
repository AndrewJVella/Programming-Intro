#https://www.geeksforgeeks.org/dsa/searching-algorithms/


import random
import copy
import time
import tabulate
#GLOBALS
SEARCHES = ["Linear", "Binary after Sort", "Binary with Sort"] #"Tree Traverse"
CHECKS = 0
CAPTURES = []
VERIFIED = False



#SEARCH MANAGER

def reset():
        global CHECKS
        CHECKS = 0

def check(n = 1):
        global CHECKS
        CHECKS += n
        return


def getTime(start, end):
        time = end - start
        return round((time / 1000))
        #You may be wondering, why have I not included a unit of time?
        #This sould return millis, but from what I can tell, this is actually tenths of a milli
        #Time calculations may be machine dependent. Idk.


def capture(name, time):
        global CAPTURES
        CAPTURES.append((name, CHECKS, time)) #appending a tuple of the sort, number of CHECKS, time passed, and verification 

def doSearch(name, target, unSortarr, veri = False): #if veri is on, verify the sort works, instead of checking performance


        #Deep copy needs to be used here.
        #Each sort runs on a copy of the unsorted array. 
        #Without deep copy, each sort would modify the same array.
        arr = copy.deepcopy(unSortarr)

        #reset  
        reset()  
        global SEARCHES
        global TIME
        #do sort
        sortedArr = []
        if name == SEARCHES[0]:

                start = time.perf_counter_ns()
                linearSearch(target, arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return

        if name == SEARCHES[1]:
                bah = quickSort(arr)
                start = time.perf_counter_ns()
                binarySearch(target, bah)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        if name == SEARCHES[2]:
                start = time.perf_counter_ns()
                binarySearch(target, quickSort(arr))
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
                
        else:   
                print()
                print(name, "Sort is not implemented.")
                print("Implemented SEARCHES:", end = " ")
                for i in SEARCHES:
                        print("\"" + i + "\"", end = " ")
                        print("\n")
        return


def SearchComparator(target, arr, Splearches = [], unsortedPrint = True):
        #the SEARCHES parameter can be used to omit SEARCHES, such as bubble sort on a large list
        global CAPTURES
        global SEARCHES


        if Splearches == []:
                Splearches = SEARCHES

        CAPTURES = []

      

        for search in Splearches: #a deep copy is used
                doSearch(search, target, arr)

        markdown_table =tabulate.tabulate(CAPTURES, ["Search", "Checks", "Time"], tablefmt="pipe", stralign="left")
        return (markdown_table)

#AUXILARIES

def swap(arr, a, b):
        temp = arr[a]
        arr[a] = arr[b]
        arr[b] = temp
        return arr


def partition(arr, low, high):
        pivot = arr[high] #largest index is our partition
        i = low -1
        for j in range(low, high):
                if arr[j] < pivot:
                        i += 1
                swap(arr, i, j)
                #print(arr, "pivot:", pivot)
                swap(arr, i + 1, high)
                # print(arr, "pivot:", pivot)
        return i + 1

def quickSort(arr, low = 0, high = -1):
        #whole array by default
        if high == -1:
                high = len(arr) -1

        if (low < high):
                partitionIndex = partition(arr, low, high)
                #recursively sort either side of the partition
                quickSort(arr, low, partitionIndex - 1)
                quickSort(arr, partitionIndex + 1, high)
        return arr



#SEARCHES
def linearSearch(target, arr):
	i = 0
	while (i < len(arr)):
                check()
                if arr[i] == target:
                        return i

                i = i + 1

	#not found
	return -1

def binarySearch(target, arr):
	#no sort in this one, only works on sorted arrays

	mid = (len(arr)) // 2

	if (len(arr) < 2):
                check()
                if (arr[0] == target):
                        return 0
                else:
                        return -1 #not found

	if(arr[mid] == target):
                check()
                return mid
	if(arr[mid] < target):
                check()
                return binarySearch(target, arr[0:mid])
	if(arr[mid] > target):
                check()
                return binarySearch(target, arr[mid:len(arr)])

#This exhausts the call stack too often
def binTreeTraverse(target, arr, root = 0, visited = []):
        #traveses a max heap in search of a target node

        if len(visited) == len(arr) and not root == target:
                return - 1

        if not root in visited:
                visited.append(root)
        print(visited)

        #search root
        if (target == arr[root]):
                check()
                return root
        
        #search left 
        left = (2 * root) + 1
        if (left < len(arr) and not left in visited):
                check()
                return binTreeTraverse(target, arr, left, visited)
        
        #search right 
        right = (2 * root) + 2
        if (right < len(arr)and not right in visited):
                check()
                return binTreeTraverse(target, arr, right, visited)

        # if this level is already visted go back
        parent = root // 2
        return binTreeTraverse(target, arr, parent, visited)


   
#ARRAY GENERATOR FUNCTIONS

def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                out.append(a[r])
                a.remove(a[r])
        return out

def test(n, m):
        global SEARCHES
        for i in range (m):
                target = random.randint(0, n - 1)
                print("Searches on shuffled array of size " + str(n)  + " with target " + str(target) + ":")
                print(SearchComparator(target, shufArr(n)))
                print()


#MAIN
if __name__ == '__main__':
        test(1500, 3)

