
i = 1

while (i <= (100)):
        if i % 3 == 0 and i % 5 == 0:
                print("FizzBuzz", end = " ")
                i = i + 1
                continue
        if i % 3 == 0:
                print("Fizz", end = " ")
                i = i + 1
                continue
        if i % 5 == 0:
                print("Buzz", end = " ")
                i = i + 1
                continue
        else:
                print(str(i), end = " ")
                i = i + 1
                
