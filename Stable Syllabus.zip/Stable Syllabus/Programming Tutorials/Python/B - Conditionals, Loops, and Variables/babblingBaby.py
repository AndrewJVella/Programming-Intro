import random

while (True): #loop forever
    i = input("Ask the Babbling Baby a question!\n> ")
    r = random.randint(1, 3)
    if r == 1:
        print("Yes")
    if r == 2:
        print("No")
    if r == 3:
        print("I dunno")
    #this is an optional bit to terminate the program
    if (len(i) == 0):
        print("Bye")
        break #break the loop
