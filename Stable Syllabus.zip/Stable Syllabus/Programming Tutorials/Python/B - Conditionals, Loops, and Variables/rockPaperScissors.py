import random

def menu():
	i = 0
	while (i == 0):
		try:
			i = int(input("Rock, Paper, Scissors\n1. Rock\n2. Paper\n3. Scissors\n> "))
		except ValueError:
			print("Please choose a number")
			i = 0
	return i

def game(player, computer):
	#optional array to print choices
	choices = ["Rock", "Paper", "Scissors"]
	print(choices[player-1] + " vs. " + choices[computer-1])
	if player == computer:
		print("It's a tie")
	if (player == 1 and computer == 2) or (player == 2 and computer == 3) or (player == 3 and computer == 1):
		print("You lose.")
	if (computer == 1 and player == 2) or (computer == 2 and player == 3) or (computer == 3 and player == 1):
		print("You win!")
def test():
        for i in range (1,4):
                for j in range (1,4):
                        print(i,j)
                        game(i,j)
def main():
        #test()
        while (True):
                game(menu(), random.randint(1,3))
main()
