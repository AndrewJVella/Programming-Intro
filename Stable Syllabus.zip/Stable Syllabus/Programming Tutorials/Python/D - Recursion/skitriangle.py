
from turtle import *

PENSIZE = 5
TRI_NAME = [0, 0] #used for debug

def getName(n):
	global TRI_NAME

	if (n > TRI_NAME[0]):
		TRI_NAME[0] = n
		TRI_NAME[1] = 0
	else:
		TRI_NAME[1] += 1
	Alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]

	return str(Alphabet[TRI_NAME[0] % 26]) + str(TRI_NAME[1])

def mid(p1, p2):

	mid = ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)
	#print("The midpoint of", p1, "and", p2, "is", mid)
	return mid

def colorPick(n):
	colors = ["black", "blue" , "forestgreen", "salmon", "darkorchid", "firebrick"]
	color(colors[n % len(colors)])

def drawpoint(n, p):
	global PENSIZE
	pensize(PENSIZE * 1.5)
	colorPick(n + 1)
	up()
	goto(p[0], p[1])
	down()
	forward(1)
	up()
	pensize(PENSIZE)

	#print(color(), p)



def drawVerts(n, vert1, vert2, vert3):
	drawpoint(n, vert1)
	drawpoint(n, vert2)
	drawpoint(n, vert3)



def drawTriangle(n, vert1, vert2, vert3):
	colorPick(n)
	up()
	goto(vert1[0], vert1[1])
	down()
	goto(vert2[0], vert2[1])
	goto(vert3[0], vert3[1])
	goto(vert1[0], vert1[1])
	up()

def drawLine(n, vert1, vert2):
	colorPick(n)
	up()
	goto(vert1[0], vert1[1])
	down()
	goto(vert2[0], vert2[1])
	up()
	print("I AM TEH LINE:", color(), vert1, vert2)

def getTri(r = 275):
	# I thought this would scale nicely, but it works only once before going all over the place
	#r is the radius of a circle in which the triangle is inscribed.
	c = [0,0]
	vert1 = (c[0], r)
	vert2 = (-r, c[1] -(r))
	vert3 = (r, c[1] -(r))
	return [vert1, vert2, vert3]


def sirtri(maxg = 0, speedy = True, n = 0, triangle = [0]):
	#base case
	if n > maxg or maxg < 1:
		return
	
	if not speedy:
		tri_name = getName(n)
		print("Hi, my name is", tri_name)

	
	#get triangle 0
	if triangle == [0]:
		triangle = getTri()
	
		
	vert1 = triangle[0] 
	vert2 = triangle[1] 
	vert3 = triangle[2] 
		
	
	if not speedy:
	#get triangle vertices
		print("Vertices:")
		print(vert1, vert2, vert3)
		drawVerts(n-1, vert1, vert2, vert3)
	#print("--\n")

	#get midpoints of triangle sides
	smp1 = mid(vert1, vert2)
	smp2 = mid(vert2, vert3)
	smp3 = mid(vert3, vert1)

	#print("Side Midpoints:")
	#drawVerts(n, smp1, smp2, smp3)
	#print("--\n")
	if (not speedy or n == maxg):
		drawTriangle(n, vert1, vert2, vert3)
		#drawTriangle(n+1, smp1, smp2, smp3)


	nextTri1 = [vert1, smp1, smp3]
	nextTri2 = [vert2, smp2, smp1]
	nextTri3 = [vert3, smp2, smp3]
	sirtri(maxg, speedy, n+1, nextTri1)
	sirtri(maxg, speedy, n+1, nextTri2)
	sirtri(maxg, speedy, n+1, nextTri3)
	return 

def main():
	speed(0) #FAAAAST
	global PENSIZE
	Screen().screensize(1600, 900)
	bgcolor("lavender")
	pensize(PENSIZE)
	st()
	sirtri(6) #number of generations.
	ht() 
	#print("Finished.")
	exitonclick()

	
main()



