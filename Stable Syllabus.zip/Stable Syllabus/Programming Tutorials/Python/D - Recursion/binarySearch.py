import random
def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out


def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out

def insertionSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        for i in range (0, len(arr) -1):
                j = i + 1
                while j > 0:
                        if (arr[j] < arr[j -1]):
                            t = arr[j]
                            arr[j] = arr[j-1]
                            arr[j-1] = t
                            #print(arr)
                        j = j - 1
        return arr

#returns index of target in arr
def binarySearch(target, arr, low = 0, high = -1):
	#by default search whole array, sort it first
	if high == -1:
		high = len(arr)
		arr = insertionSort(arr)
		#print(arr)

	mid = (high+low) // 2
	#print(low, mid, high)
	#base case
	if (mid == low):
		if (arr[low] == target):
			return low
		else:
			return -1 #not found

	if(arr[mid] == target):
		return mid
	if(arr[mid] < target):
		return binarySearch(target, arr, mid, high)
	if(arr[mid] > target):
		return binarySearch(target, arr, low, mid)


def linearSearch(target, arr):
	i = 0
	while (i < len(arr)):
		if arr[i] == target:
			return i
		i = i + 1

	#not found
	return -1


def main(n):

	arr = shufArr(n)
	target = random.randint(0, n+5) #pick a target that may not be in the array

	print(arr)
	print("Target:", target)

	linear = linearSearch(target, arr)
	binary = binarySearch(target, arr)

	if(linear == -1):
		print("Linear: target not found")
	if(binary == -1):
		print("Binary: target not found")
	if(linear > -1):
		print("Linear: target is at index", linear)
	if(binary > -1):
		print("Binary: target is at sorted index", binary)

main(30)

