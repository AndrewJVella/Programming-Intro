#iterative
def ifact(n):
        i = (n-1)
        while(i > 1):
                n = n * i
                i = i -1
        return n
        
        
#recursive
def rfact(n):
        #base case
        if (n == 1):
                return n
        #recursive case
        if (n > 1):
                return n * rfact(n - 1)
        

def main(n):
        for i in range(1,n + 1):
                print(i, ifact(i), rfact(i))


main(10)

