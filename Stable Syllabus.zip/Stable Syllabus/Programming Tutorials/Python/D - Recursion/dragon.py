from turtle import *

PENSIZE = 2

def revArr(a):
        #produces reversed list
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1
                
        return out



def getturns(turns):
	antiturns = [] #gotta call it something..
	blurns = revArr(turns)

	for b in blurns:
		antiturns.append(not b)

	turns.append(True)

	for t in antiturns:
		turns.append(t)
	
	return turns

#I will use True and False for Left and Right. Us lefties deserve it after all the slander.
def dragon(maxg, n =0, turns = [], c = 15000):
	if n > maxg or n < 0:
		return
	

	up()
	goto(-50, 150)
	setheading(90)
	down()

	turns = getturns(turns)
	forwardStep = (c / (2 ** n))

	if (n == maxg):
		color("lavender")
		st()
		for t in turns:
			forward(forwardStep)
			if t:
				left(90)
			else:
				right(90)

		forward(forwardStep)

	dragon(maxg, n + 1, turns)

def main():
	global PENSIZE
	ht()
	Screen().screensize(1600, 900)
	bgcolor("black")
	pensize(PENSIZE)
	dragon(12) #number of generations.
	ht() 
	#print("Finished.")
	exitonclick()
main()