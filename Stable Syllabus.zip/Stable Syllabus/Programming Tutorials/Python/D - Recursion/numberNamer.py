def counter(i, th = True, stringInput = True):

    if stringInput: #if the input is a string, validate it for testing
        try:
           i = int(i)
        except ValueError:
            try:
                i = int(i.replace(" ", "").replace(".", "").replace(",", ""))
            except ValueError:
               return "Silly bean, pick a number!"

    i = int(i)
    if i < 1:
        return ""
    out = ""

    #see else case
    c = 0 
    modulus = 0 
    ##

    Units = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"]
    Tens = ["", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]

    if i < 21:
        return "-" + Units[i] 
    if i < 100:
        return "-" +  Tens[i // 10] + counter(i % 10, th) 
    if  th and  i > 999 and i < 100000 and (i % 1000) // 100 == 0 : #if thousands are enabled, i < 10^5, and the hundreds digit is nonzero, use "thousand" not "ten hundred". So 3000 is "three thousand" not "thirty hundred"
        #print(i // 1000, i % 1000)
        return counter(i // 1000, th) + "-thousand" + counter(i % 1000, th) 
    if i < 10000:
        return counter(i // 100, th) + "-hundred" + counter(i % 100, th)
    else:
        return "ten thousand or greater"

def main():
        print(counter(input("A number, please\n> ")).strip("-"))
main()
