
def pascalTri(n):
	print("1")
	print("1 1")
	previous = [1, 1]
	for i in range(2, n):
		nextUp = [1]
		j = 0
		for j in range(len(previous) - 1):
			nextUp.append(previous[j] + previous[j+1])
		nextUp.append(1)
		for i in nextUp:
			print(i, end = " ")
		previous = nextUp
		print()


pascalTri(10)




