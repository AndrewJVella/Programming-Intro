import random
def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1
                
        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out

def linearSearch(target, arr):
	i = 0
	while (i < len(arr)):
		if arr[i] == target:
			return i
		i = i + 1

	#not found
	return -1

def main(n):
	arr = shufArr(n)
	target = random.randint(0, n+5) #pick a target that may not be in the array

	print(arr)
	print("Target:", target)

	result = linearSearch(target, arr)

	if result == -1:
		print("Target not found")
	if result > -1:
		print("Target found at index", result)

main(25)