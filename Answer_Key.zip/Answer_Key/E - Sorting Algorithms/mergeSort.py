

import random
def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out
def swap(a,b):
    if a > b:
        print([b,a])
        return [b,a]
    return [a,b]

def merge(arrA, arrB):
    #if arrays are different lengths, a is always the shorter one
    if len(arrA) > len(arrB):
            temp = arrB
            arrB = arrA
            arrA = temp

    #base cases
    if len(arrB) == 0:
        return arrA
    if len(arrA) == 0:
        return arrB

    #Merge sort is a bit of a paradox.
    #You need to merge lists to sort them,
    #and you need to sort lists to merge them.
    #This is the "paradox resolver" and (despite the fact this is a solved problem) this took like two hours
    else:
        arrA = mergeSort(arrA)
        arrB = mergeSort(arrB)
        merged = []
        while len(arrA) > 0 and len(arrB) > 0:
            print(arrA, arrB, merged)
            if arrA[0] < arrB[0]:
                merged.append(arrA[0])
                arrA.remove(arrA[0])
                continue
            if arrB[0] < arrA[0]:
                merged.append(arrB[0])
                arrB.remove(arrB[0])
                continue
            if arrB[0] == arrA[0]:
                merged.append(arrA[0])
                arrA.remove(arrA[0])
                merged.append(arrB[0])
                arrB.remove(arrB[0])
                continue

        if len(arrA) > 0:
            for a in arrA:
                merged.append(a)
        if len(arrB) > 0:
            for b in arrB:
                merged.append(b)
    print(merged)
    return merged
'''
   #This sorts any list of length 3, but it needs to be generalized
    if (len(arrA) == 1 and len(arrB) == 2):
        arrB = swap(arrB[0], arrB[1]) #sort arrB
        #print(arrA, arrB)

        if (arrA[0] <= arrB[0]):
            return [arrA[0], arrB[0], arrB[1]]
        if (arrA[0] > arrB[1]):
            return [arrB[0], arrB[1], arrA[0]]
        if (arrA[0] > arrB[0]) and (arrA[0] < arrB[1]):
            return [arrB[0], arrA[0], arrB[1]]
            '''




#This is an out-of-place merge sort, for visualization (or, it will be...)
def mergeSort(arr):
        #base cases
        if len(arr) == 2:
            return merge([arr[0]], [arr[1]])
        if len(arr) == 1:
            return arr
        #split the array into left and right
        start = 0
        end = len(arr) -1
        pivot = (start + end) // 2 #get the middle index of the list by calculating the average
        left = []
        right = []

        #get left side
        for i in range(0, pivot + 1):
            left.append(arr[i])
        #get right side
        for i in range(pivot + 1,len(arr)):
            right.append(arr[i])
        print(left, right)
        return merge(left, right)

def insertionSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        for i in range (0, len(arr) -1):
                j = i + 1
                while j > 0:
                        if (arr[j] < arr[j -1]):
                            t = arr[j]
                            arr[j] = arr[j-1]
                            arr[j-1] = t
                            print(arr)
                        j = j - 1
        return arr

def timSort(arr, run = 8):
    #uses insertion sort on runs, and merges them together. A run is a contiguous segment of the array, of length "run"
    out = []
    runCount = len(arr) // run
    runCounter = 0 #counts from 0 to runCount
    r1 = 0
    r2 = 0
    r3 = 0

    #sort and merge runs
    while runCounter < runCount:
        r1 = run * runCounter
        r2 = r1 + (run) #slices exclude the max
        r3 = len(arr)
        sortme = arr[r1:r2] #this is a slice: array[a:b] is an array of items from array[a] to array[b-1]
        #print("sortme: ", sortme, r1, r2)
        out = merge(out, insertionSort(sortme))
        runCounter += 1

    r1 = run * runCounter
    sortme = arr[r1:r3]
    #print("sortME: ", sortme, r1, r3)
    out = merge(out, insertionSort(arr[r1:r3]))

    return out

def main(n):
    print("Insertion Sort:\n")
    arr = ordArr(n)
    print(arr)
    print(insertionSort(arr))
    print("--")

    arr = shufArr(n)
    print(arr)
    print(insertionSort(arr))
    print("--")


    arr = revArr(n)
    print(arr)
    print(insertionSort(arr))
    print("--")

    print("Merge Sort:\n")
    arr = ordArr(n)
    print(arr)
    print(mergeSort(arr))
    print("--")

    arr = shufArr(n)
    print(arr)
    print(mergeSort(arr))
    print("--")


    arr = revArr(n)
    print(arr)
    print(mergeSort(arr))
    print("--")

    print("Tim Sort:\n")
    arr = ordArr(n)
    print(arr)
    print(timSort(arr))
    print("--")

    arr = shufArr(n)
    print(arr)
    print(timSort(arr))
    print("--")


    arr = revArr(n)
    print(arr)
    print(timSort(arr))
    print("--")

main(25)
