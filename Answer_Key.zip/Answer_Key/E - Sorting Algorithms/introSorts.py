#IDLE uses really small text...

import random
def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1
                
        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out


def bubbleSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        
        #given arr is an array
        n = len(arr)
        i = 0
        x = 1

        while(x < (n + 1)):
                while(i < n - x):
                        if (arr[i] > arr[i + 1]):
                            #swap
                            t = arr[i]
                            arr[i] = arr[i + 1]
                            arr[i+1] = t
                            print(arr)   
                        i = i +1
                i =0
                x = x+1
        return arr

def selectionSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        maxIndex = len(arr) - 1
        maxValue = -1

        while(maxIndex > 0):
                i = 0
                indexUnsortedMax = -1
                #get max unsorted value
                while (i <= maxIndex):  #this inequality was diabolical. It took an hour to notice I had written '<', not '<='. 
                        if arr[i] > maxValue:
                                maxValue = arr[i]
                                indexUnsortedMax = i
                        i = i + 1
                #print("unsorted max index is", indexUnsortedMax)
                if indexUnsortedMax > - 1:
                        swap = arr[maxIndex]
                        arr[maxIndex] = arr[indexUnsortedMax]
                        arr[indexUnsortedMax] = swap
                        maxValue = -1
                        print(arr)     
                i = 0
                maxIndex = maxIndex - 1
        return arr
                
def insertionSort(arr): 
        if len(arr) < 2: #already sorted case
                return arr
        for i in range (0, len(arr) -1):
                j = i + 1
                while j > 0:
                        if (arr[j] < arr[j -1]):
                            t = arr[j]
                            arr[j] = arr[j-1]
                            arr[j-1] = t
                            print(arr)
                        j = j - 1
        return arr

                                    
def main():
        n = 10
        print("Bubble Sort")
        arr = ordArr(n)
        print(arr)
        print(bubbleSort(arr))
        print("--")
        arr = shufArr(n)
        print(arr)
        print(bubbleSort(arr))
        print("--")
        arr = revArr(n)
        print(arr)
        print(bubbleSort(arr))
        print("--")
        
        print("Selection Sort")
        arr = ordArr(n)
        print(arr)
        print(selectionSort(arr))
        print("--")
        arr = shufArr(n)
        print(arr)
        print(selectionSort(arr))
        print("--")
        arr = revArr(n)
        print(arr)
        print(selectionSort(arr))
        print("--")

        print("Insertion Sort")
        arr = ordArr(n)
        print(arr)
        print(insertionSort(arr))
        print("--")
        arr = shufArr(n)
        print(arr)
        print(insertionSort(arr))
        print("--")
        arr = revArr(n)
        print(arr)
        print(insertionSort(arr))
        print("--")
        
main()
        
        


        
        
