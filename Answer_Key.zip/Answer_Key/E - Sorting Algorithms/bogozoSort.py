import random
import time

def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                out.append(a[r])
                a.remove(a[r])
        return out


   
        
def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out


def verify(arr):

        for i in range(0, len(arr) -1):
                if (arr[i] > arr[i+1]):
                        return False
        return True

def swap(arr, a, b):
        temp = arr[a]
        arr[a] = arr[b]
        arr[b] = temp
        return arr

#an impractical sort that swaps randomly, but helps us learn about verifiers
def bozoSort(arr):
        while not verify(arr):
                print(arr)
                a = random.randint(0, len(arr) -1)
                b = a
                #ensure that b is not a
                while (a == b):
                        b = random.randint(0, len(arr) -1)
                arr = swap(arr, a, b)
                #adds a delay
                time.sleep(.3)
        return arr

def bogoSort(arr):
        while not verify(arr):
                print(arr)

                #shuffle array
                out = []
                while(len(arr) > 0):
                        r = random.randint(1, len(arr)) -1
                        out.append(arr[r])
                        arr.remove(arr[r])
                arr =  out
                #adds a delay
                time.sleep(.3)
        return arr

def bogozoSort(arr):
        while not verify(arr):
                print(arr)
                arr = bogoSort(arr)
                if not verify(arr):
                        arr = bozoSort(arr)
                time.sleep(.3)
        return arr

n = 4
print("Bozo Sort:")
print(bozoSort(revArr(n)))
print()
print("Bogo Sort:")
print(bogoSort(revArr(n)))
print()
print("Bogozo Sort:")
print(bogozoSort(revArr(n)))