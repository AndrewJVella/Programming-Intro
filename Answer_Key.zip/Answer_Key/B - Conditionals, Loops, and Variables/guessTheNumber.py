import random

def guessNumber(a= 1, b = 10):
        try:
                #input sanitization
                a = int(a)
                b = int(b)
        except ValueError:
                a = 1
                b = 10
                return
        
        n = random.randint(a,b)
        g = -1
        print("I am thinking of a number between", str(a), "and", str(b), "\nGo on and guess it!")
        guesses = 0
        while (not n == g):
                try:
                        g = int(input("> "))
                except ValueError:
                        print("Silly bean! Pick a number!")
                if (g < n):
                        print("Higher!")
                if (g > n):
                        print("Lower!")
                guesses += 1
        print("You got it! I picked", n)
        print("You got it in " + str(guesses) +" guesses")
guessNumber(1, 10)
                
