#As I wrtie this it is clear that this is probably best in the array section.
#I can try implementing with and without an array.
# \ is a line continuation 



story = "So I wake up this morining, and the first thing I do is " \
+ input("Enter a verb:\n> ") \
+ ". I know today is " + input("Enter the name of a special day:\n> ")\
+ "and I am feeling" + input("Enter an emotion:\n> ") \
+ " So I get up to tell my friend, " + input("Enter a name") \
+ " but first I gotta have breakfast. So I eat some " + input("Enter a food\n> ")\
+ " and it tastes " + input("Enter an adjective\n> ") \
+ " I say \"" + input("Enter an interjection\n> ") + "!\""\
+ "and see " + input("Enter a name\n> ")   + ", (sometimes I call them that)"\
+ "just in time to " + input("Enter a verb\n> ") + " in their face!"

print(story)
