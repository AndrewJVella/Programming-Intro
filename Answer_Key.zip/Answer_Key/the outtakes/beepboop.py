#only works on windows
import winsound
#from pyo import *


def main():
    print("Playing")
    winsound.Beep(262,500) #frequency in hrtz, and duration in millis
    winsound.Beep(294,500)
    winsound.Beep(326,500)
    winsound.Beep(348,500)
    winsound.Beep(392,500)
    winsound.Beep(440,500)
    winsound.Beep(494,500)
    winsound.Beep(518,500)



    #winsound only works on windows
    print("Finished")

    '''
    #via http://ajaxsoundstudio.com/pyodoc/examples/01-intro/02-sine-tone.html
    # Creates and boots the server. 
    # The user should send the "start" command from the GUI.
    s = Server().boot()
    # Drops the gain by 20 dB.
    s.amp = 0.1

    # Creates a sine wave player.   
    # The out() method starts the processing
    # and sends the signal to the output.
    a = Sine().out()
    '''
main()
