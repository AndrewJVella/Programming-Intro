i = input("Look a truth machine!\n> ")
if i == "0":
    print("0")
else:
    while(True):
        print("1", end = "")
