#sirpinski had a big in it that looked cool
def insigniaMachine(): #r is the radius of a circle in which the trianngle is inscribed. rdiv is a constant
	n = 1
	centers = [(0,0)]
	r = 250
	rdiv = 1.25
	#base case
	if n == -1 or r == 0:
		return

	
	nextCenters = []
	for c in centers:
		#get triangle vertices
		vert1 = (c[0], r)
		vert2 = (-r, c[1] -(r//rdiv))
		vert3 = (r, c[1] -(r//rdiv))

		#populate the next generation of triangles (get centers of next gen triangles)
		mp1 = mid(vert1, vert2)
		mp2 = mid(vert2, vert3)
		mp3 = mid(vert3, vert1)

		#naming is hard
		mmp1 = mid(mp1,c)
		mmp2 = mid(mp2,c)
		mmp3 = mid(mp3,c)

		#print(vert1,vert2,vert3)
		#print(mp1, mp2, mp3)
		#print(mmp1, mmp2, mmp3)

		nextCenters.append(mmp1)
		nextCenters.append(mmp2)
		nextCenters.append(mmp2)

		#draw triangles
		#print(vert1,vert2,vert3)			
		ht()
		up()
		goto(vert1[0], vert1[1])
		st()
		down()
		goto(vert2[0], vert2[1])
		goto(vert3[0], vert3[1])
		goto(vert1[0], vert1[1])
		ht()
		up()


	return insigniaMachine(n - 1, nextCenters, r // 4)




#THIS IS COOL BUG NUMBER 2

	#So this implementation is depth first, drawing everything in one corner, and then the next, and then the next
#I'd like to go breadth first:
	
	#gen 0 -> make a big equilateral triangle 
	
	#gen 1 -> nest 3 equilateral triangles in gen0, at 1/4 the area of gen0. 
	#Let each triangle share a vertex with gen0;
	#leaving an inverted triangle in the center of gen0.

	#gen2 follows by recursion, and also induction I think...
	# it uses nine triangles. (3^n) triangles all the way down

	#This could be do in reverse too

	#Anyway, I think this is actually a level six project of sorts, not level 4.
	#The best way I cna think of to implement this is as a ternary tree of points.
	#Each point is at the center of a triangle, with the root centering gen0.

	#To get the centers of gen 1 triangles: 
	#Start by taking the midpoints of the sides of gen0.
	#Draw segments perpendicular to the sides of gen0, at the side-midpoints
	#Have these segments meet at the center of gen0
	#The midpoints of these segments are the centers of the triangles for gen1
	#Recur for gen2

	#An intersting thing about this is that the tree can grow to aribitrary generations
	#There is no "base case" for the recursion 


	#ternary tree arr: 3n, 3n+1, 3n+2


#My specific goal is to render each generation of the sirpinski triangle completely before continuing on the next
from turtle import *

PENSIZE = 5
TRINAMES = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]

def mid(p1, p2):

	mid = ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)
	#print("The midpoint of", p1, "and", p2, "is", mid)
	return mid

def colorPick(n):
	colors = ["firebrick", "blue" , "forestgreen", "salmon", "darkorchid", "black"]
	color(colors[n % len(colors)])

def drawpoint(n, p):
	global PENSIZE
	pensize(PENSIZE * 3)
	colorPick(n + 1)
	up()
	goto(p[0], p[1])
	down()
	forward(1)
	up()
	pensize(PENSIZE)

	print(color(), p)



def drawVerts(n, vert1, vert2, vert3):
	drawpoint(n, vert1)
	drawpoint(n, vert2)
	drawpoint(n, vert3)



def drawTriagle(n, vert1, vert2, vert3):
	colorPick(n)
	up()
	goto(vert1[0], vert1[1])
	down()
	goto(vert2[0], vert2[1])
	goto(vert3[0], vert3[1])
	goto(vert1[0], vert1[1])
	up()

def drawLine(n, vert1, vert2):
	colorPick(n)
	up()
	goto(vert1[0], vert1[1])
	down()
	goto(vert2[0], vert2[1])
	up()

def sirtri(maxg = 0, n = 0, centers = [(0,0)], r = 250, rdiv = 1.25): #r is the radius of a circle in which the triangle is inscribed. rdiv is a constant
	tri_id = 0
	
	#base case
	if n > maxg or r == 0 or maxg < 1:
		return

	
	nextCenters = []
	for c in centers:
		#get triangle vertices
		vert1 = (c[0], r)
		vert2 = (-r, c[1] -(r//rdiv))
		vert3 = (r, c[1] -(r//rdiv))

		print("---")
		#populate the next generation of triangles (get centers of next gen triangles)
		smp1 = mid(vert1, vert2)
		smp2 = mid(vert2, vert3)
		smp3 = mid(vert3, vert1)

		#so the midpoints of 1-A can make an inverted triangle. I need the midpoints of the sides of that one too!
		usmp3 = mid(smp1, smp2)
		usmp1 = mid(smp2, smp3)
		usmp2 = mid(smp3, smp1)
		
		# I take a segment from the vertex of the original triangle, to the midpoint of the side of the inverted triangle
		# Get the midpoint of the resulting segment and you have the center of a smaller non-inverted triangle, a "verted" triangle
		#Which can be used to recur!
		mmp1 = mid(vert1,usmp1) #I HAD THE WRONG SET OF POINTS FOR OVER TWO HOURS WOOHOO I WAS USING c's!
		mmp2 = mid(vert2,usmp2)
		mmp3 = mid(vert3,usmp3)


		nextCenters.append(mmp1)
		nextCenters.append(mmp2)
		nextCenters.append(mmp3)
		print("===")



		#draw triangles
		global TRINAMES
		print("TRIANGLE", str(n+1) + " - " +TRINAMES[tri_id])
		print("Center:")
		drawpoint(n, c)
		print()

		print("Vertices:")
		drawVerts(n-1, vert1, vert2, vert3)
		print()

		print("Side Midpoints:")
		drawVerts(n, smp1, smp2, smp3)
		print()

		print("Inverted Side Midpoints:")
		drawVerts(n + 1, usmp1, usmp2, usmp3)
		print()

		drawLine(n+ 2,vert1,usmp1)
		drawLine(n+ 2,vert2,usmp2)
		drawLine(n+ 2,vert3,usmp3)

		print("Next Centers")
		drawVerts(n +  2, mmp1, mmp2, mmp3)
		print()

		print(nextCenters)
		#return



		drawTriagle(n, vert1, vert2, vert3)
		drawTriagle(n+1, smp1, smp2, smp3)

		tri_id = tri_id + 1


	return #sirtri(maxg, n + 1, nextCenters, r // 4)

def main():
	global PENSIZE
	bgcolor("lavender")
	pensize(PENSIZE)
	st()
	sirtri(1)
	exitonclick()

	


main()



