import random
def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i)
        return out 
def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out


def linearSearch(target, arr):
	i = 0
	while (i < len(arr)):
		if arr[i] == target:
			return i
		i = i + 1

	#not found
	return -1

def binTreeTraverse(target, arr, root = 0, visited = []):
	#traveses a max heap in search of a target node

	if len(visited) == len(arr) and not root == target:
		return - 1

	if not root in visited:
		visited.append(root)
	#print(visited)

	#search root
	if (target == arr[root]):
		return root
	
	#search left 
	left = (2 * root) + 1
	if (left < len(arr) and not left in visited):
		return binTreeTraverse(target, arr, left, visited)
	
	#search right 
	right = (2 * root) + 2
	if (right < len(arr)and not right in visited):
		return binTreeTraverse(target, arr, right, visited)

	# if this level is already visted go back
	parent = root // 2
	return binTreeTraverse(target, arr, parent, visited)

def main(n, arr = []):

	if arr == []:
		arr = shufArr(n)
		target = random.randint(0, n + (n // 4))
	else:
		target = n
	control = linearSearch(target, arr)

	print(arr)
	result  = binTreeTraverse(target, arr)

	print("Target:", target)
	if result > -1:
		print("Tree Search found target at index", result)
	if result == -1:
		print("Tree Search target not found")

	if control > -1:
		print("Linear Search found target at index", control)
	if control == -1:
		print("Linear Search target not found")
main(50)
#https://www.geeksforgeeks.org/dsa/binary-heap/
