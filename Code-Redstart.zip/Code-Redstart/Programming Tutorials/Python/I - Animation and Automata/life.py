from turtle import *
import math
import random
import copy
import time

#https://cs111.wellesley.edu/reference/colors
COLORS = ["fireBrick4", "fireBrick2", "Sienna4", "Sienna2", "Goldenrod4", "Goldenrod2", "SeaGreen4", "SeaGreen2", "SteelBlue4", "SteelBlue2",  "SlateBlue4", "SlateBlue2", "MediumOrchid4", "MediumOrchid2"]
MIN = 4
MAX = 64

def maxScreen(): #https://stackoverflow.com/questions/34687998/turtle-screen-fullscreen-on-program-startup/60138928#60138928
    screen = Screen()
    screen.setup(width = 1.0, height = 1.0)
    canvas = screen.getcanvas()
    root = canvas.winfo_toplevel()
    #root.overrideredirect(1) #comment this out so for the window buttons

def texter(text, size = 16):
    size = int(size)
    write(text, align="center", font=("Helvetica", size, "bold"))

def indexToCol(i):
        if i < 26: #A to Z
            return chr(i + 65) #A is 65
        if i > 25: #AA and beyond
            return str(indexToCol((i // 26) -1)) + indexToCol((i % 26))
    
def printboard(board):
    for row in board:
        print(row)

def init(x = 1, y = 1):
    #just some init
    screensize(x,y)
    bgcolor("black")
    #shape("turtle")
    ht()
    tracer(False)
    setundobuffer(None)
    maxScreen()

def randboard(x, y):
    arr = []

    for i in range (y):
        row = []
        for j in range (x):
            row.append(random.randint(0,1))
        arr.append(row)
    return arr

def testRender(n):
    for i in range(1, 20):
        clear()
        render(randboard(i, i), n)
    exitonclick()


def isDead(arr):
    for i in arr:
        for j in i:
            if j > 0:
                return False
    return True

def setCellbyboardIndex(row, col, board):
    col = col % len(board[0])
    row = row % len(board)
    board[row][col] = 1

    return board

def getCellbyboardIndex(row, col, board):
    col = col % len(board[0])
    row = row % len(board)
    return board[row][col]


def colDebug(n):
    for i in range(n):
        l = indexToCol(i)
        c = letToCol(l)
        print(i, l, c)
        if c != i:
            pass
            #print("Oops!")
            #return

def letToCol(letter):
    out = 0
    i = 0
    j = len(letter)

    #print("--")
    while i < len(letter):
    
        cat = (ord(letter[i]) - 64) 
        dog = (26 ** (j - 1))
        out += cat * dog
        #print("at (i,j) = (", i, j, ") ->", letter[i], "=", cat, "<>", dog, "<>", cat * dog)

        i = i + 1
        j = j - 1
    return out - 1

def mapCellToArr(inps, board):
    #converts "A1" to board[0][0] and the like
    #print(inps)
    for cell in inps:
        cell = cell.upper()
        letter = ""
        number = ""

        for char in cell:
            if char.isdigit():
                number += char
            else:
                letter += char
        #print(cell, letter, number)
        row = int(number)
        col = letToCol(letter)


        #print(col, row)
        board = setCellbyboardIndex(row, col, board)
    #printboard(board)
    return board

def render(arr, size, coloring = 0, buffer =2): #assume the array encodes cells on an x by y board of cells
    clear() #the screen needs to be cleared for each render, to prevent slowdowns
    if len(arr) < 4 or len(arr) > (size//2):
        #do not render
        exit()
        return

    global COLORS

    coloring = (coloring * 2) % len(COLORS)

    width = len(arr[0])
    height = len(arr)
    area = width * height
    cellSize = size / width
    penSize = cellSize - (buffer)

    pensize(penSize)
    i = 0
    up()
    startX = - size // 2
    startY = size // 2

    #printing board indicators to screen 
    color(COLORS[coloring + 1])
    for i in range(width):
        if i % 5 == 0:
            goto(startX + (cellSize * i), startY + cellSize // 2)
            texter(indexToCol(i), cellSize / 1.5)
    for i in range(height):
        if i % 5 == 0:
            goto(startX - cellSize, startY - (cellSize * (i + 1)) + cellSize // 2 )  
            texter(i, cellSize / 1.5)


    #rendering the board

    goto(startX, startY)

    row = 0
    col = 0

    while row < len(arr):
        while col < len(arr[row]):      
            down()
            try:
                color(COLORS[arr[row][col] + coloring])
            except IndexError:
                color("black")
            forward(1)
            forward(-1)
            up()
            setx(xcor() + cellSize)
            col = col + 1
            
        sety(ycor() - cellSize)
        setx(startX)
        row = row + 1
        col = 0
    update()


def getCenter(boardX, boardY):
    #if would be cool to specify offesets from the center of the board 
    #like "(*-3, *+3)" for "three left of center, three down of center"
    return (indexToCol(boardX // 2), boardY // 2)

def nextLife(board): #computes next generation of Life; takes a board as a 2d array
    col = 0
    row = 0
    out = []

    while row < len(board):
        outRow = []
        while col < len(board[row]):
            #get each neighbor of current cell
            north = getCellbyboardIndex(row - 1, col, board)
            south = getCellbyboardIndex(row + 1, col, board)
            east = getCellbyboardIndex(row, col + 1, board)
            west = getCellbyboardIndex(row, col - 1, board)
            northEast = getCellbyboardIndex(row - 1, col + 1, board)
            nortWest = getCellbyboardIndex(row - 1, col - 1, board)
            southEast = getCellbyboardIndex(row + 1, col + 1, board)
            southWest = getCellbyboardIndex(row + 1, col - 1, board)

            neighborSum = north + south + east + west + northEast + nortWest + southEast + southWest
            alive = None
            if neighborSum < 2 or neighborSum > 3:
                alive = False #living cell dies
            if neighborSum == 3:
                alive = True #a cell is (re)born
            if neighborSum == 2:
                alive = (board[row][col] == 1)  # exactly two living neighbors leaves cell unchanged
        
            if alive:
                outRow.append(1)
            if not alive:
                outRow.append(0) 

            col = col+1
        row = row + 1
        col = 0

        out.append(outRow)
    return out

def life(inps= ["B2", "C3", "D1", "D2", "D3"], n = -1, boardWidth = 26, boardHeight = 26, delay = .03, coloring = 3, scale = 1):
    #Default: put a glider on the diagonal of a 26 by 26 board on a screen of 600 by 450 pixels, and run for an unlimited number of generations, with a delay of 1/30th of a second.
    global MIN
    global MAX

    #these are some guardrails to ensure boards are of a reasonable size
    if boardWidth < MIN:
        boardWidth = MIN
    if boardHeight < MIN:
        boardHeight = MIN
    if boardWidth > MAX:
        boardWidth = MAX
    if boardHeight > MAX:
        boardHeight = MAX


    

    global COLORS
    rainbow = coloring == -1 
    if rainbow:
        coloring = 3

    screenWidth = 600 
    screenHeight = 450
    startEndDelay = 2
    init(screenWidth * scale, screenHeight * scale)
    #print("Expected:", screenWidth * scale, screenHeight * scale, "Got:", window_width(), window_height()) 

    centerTup = getCenter(boardWidth, boardHeight)
    print("Center cell is at:", str(centerTup[0]) + str(centerTup[1]) , "on a", boardWidth, "by", boardHeight, "board")
    print("Starting with live cells: ", inps)

    #generating board
    board = []
    row = []

    for i in range(boardWidth):
        row.append(0)
    for i in range(boardHeight):
        board.append(copy.deepcopy(row)) #need to pass by value here

    board = mapCellToArr(inps, board)



    render(board, screenHeight, coloring)
    time.sleep(startEndDelay)

    i = 0
    while not i == n: #if n is -1 or less, continue until board dies

        if i % 20 == 0 and rainbow:
            coloring = (coloring + 1 % len(COLORS))


        board = nextLife(board)
        render(board, screenHeight, coloring)
        if isDead(board):
            time.sleep(startEndDelay)
            return
        i = i + 1
        time.sleep(delay)
    time.sleep(startEndDelay)
    return



def pulsar():
    life(["C4", "C5", "C6", "C10", "C11", "C12", "E2", "E7", "E9", "E14","F2", "F7", "F9", "F14","G2", "G7", "G9", "G14", "H4", "H5", "H6", "H10", "H11", "H12", "J4", "J5", "J6", "J10", "J11", "J12", "K2", "K7", "K9", "K14","L2", "L7", "L9", "L14","M2", "M7", "M9", "M14", "O4", "O5", "O6", "O10", "O11", "O12"], -1, 16, 16, .5, -1)

def rPentomino():
    #life(["AA3", "AA4", "AA5"], -1, 30, 30)
    life(["Z26", "AA25", "AA26", "AA27", "AB25"], -1, 52, 52)

def switchEngine():
    life(["Z26", "AA25", "AA27", "AC25", "AC28", "AD27", "AD28", "AE28"], -1, 52, 52)

def thunderBird():
    life(["AE32", "AF32", "AG32", "AF34", "AF35", "AF36"], -1, 64, 64)  

def piHeptomino():
    life(["AE32", "AF32", "AG32", "AE33", "AE34", "AG33", "AG34"], -1, 64, 64)

def acorn():
    life(["AE36", "AF34", "AF36", "AH35", "AI36", "AJ36", "AK36"], -1, 64, 64)
    
def gosperGliderGun():
    life(["B5", "C5", "B6", "C6","AJ3", "AK3", "AJ4", "AK4", "L5", "L6", "L7", "M4", "M8", "N3", "N9", "O3", "O9", "P6", "Q4", "Q8", "R5", "R6", "R7", "S6", "V3", "V4", "V5", "W3", "W4", "W5", "X2", "X6", "Z1", "Z2", "Z6", "Z7"], -1, 52, 52)  

if __name__ == '__main__':

    try:
        life()

    except Terminator:
        pass #optional try-except for the stacktrace 

#This program renders cells on an x, y board.
#Each cell can have an integer state denoted by a color.

#Cells are named according to spreadsheet convention (but still counting from zero).
#Cells are denoted by col and row.
#cols are denoted by (Latin) letter and rows are denoted by number.
#The cell in the north west corner is A0. 
#A1 is south of A0. B0 is east of A0.
#col Z is followed by col AA, which is followed by col AB.
#So cells can continue to infinity 