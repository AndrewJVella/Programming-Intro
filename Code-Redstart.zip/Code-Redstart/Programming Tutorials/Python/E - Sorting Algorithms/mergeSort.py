


import random
def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out


#MERGE SORT. YOU HAVE ACTIVATED THE DEBUG PLAYLIST. YOU WILL PLAY NICE WITH THE VISUALIZER NOW. 
#YOU FOOL! DO YOU THINK YOU CAN BEST ME???
#MERGE SORT. PREPARE FOR IMPLEMENTATION. PREPARE FOR HUMBLING.
#REFACTORIZER! GO!


#s, w, and e; pointers to the start, middle, and end indices on an array, to partition the array in place 
def merge(arr, s, m, e):
    merge = []
    left = s
    right = m

    #merging
   # print("subarray:", arr)
    #print ("left:", arr[left:m], "right:", arr[right:e])
    while left < m and right < e:
        if arr[left] < arr[right]:
            merge.append(arr[left])
            left = left + 1
            continue
        if arr[right] < arr[left]:
            merge.append(arr[right])
            right = right + 1
            continue
        if arr[left] == arr[right]:
            merge.append(arr[left])
            merge.append(arr[right])
            left = left + 1
            right = right + 1

    #add any leftovers to merge list
    if left == m:
        while right < e:
            merge.append(arr[right])
            right = right + 1
    if right == e:
        while left < m:
            merge.append(arr[left])
            left = left + 1


    #write merge to array
    x = 0
    while (s + x) < e:
        arr[s + x] = merge[x]
        x = x + 1
    return arr #BEHOLD! THE ENTIRE ARRAY WILL BE RETURNED IN FULL!

def mergeSort(arr, s = 0, e = -1):
    if e == -1: #defaults to sorting the entire array
        e = len(arr)
   
    #base cases
    if e - s < 2: #if array is too small to require any sorting 
        return arr
    if e - s == 2 and arr[s] > arr[s + 1]: #if array is of two items, swap as needed
        t = arr[s]
        arr[s] = arr[s+1]
        arr[s+1] = t
        
        return arr

    #get the middle, dividing into left and right
    m = (s + e) // 2 

    arr = mergeSort(arr, s, m) #sort left
    arr = mergeSort(arr, m, e) #sort right
    arr = merge(arr, s, m, e) #merges left and right as a sorted array
    #print(arr)
    return arr

#This sort works, but the visualizer only sorts 99 out of 100 elements. I do not know why 
def main(n):
    print("Merge Sort:\n")
    arr = ordArr(n)
    print(arr)
    print(mergeSort(arr))
    print("--")
    arr = shufArr(n)
    print(arr)
    print(mergeSort(arr))
    print("--")
    arr = revArr(n)
    print(arr)
    print(mergeSort(arr))
    print("--")

main(25)
