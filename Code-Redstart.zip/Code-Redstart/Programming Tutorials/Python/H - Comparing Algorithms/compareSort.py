
import random
import copy
import time
import tabulate
#GLOBALS
SORTS = ["Bubble", "Select", "Insert", "Shell", "Merge", "Heap", "Quick"] #"Tim (8)", "Tim (64)"
COMPARES = 0
CAPTURES = []
VERIFIED = False



#SORT MANAGER

def reset():
        global COMPARES
        COMPARES = 0

def compare(n = 1):
        global COMPARES
        COMPARES += n

def verify(arr):

        for i in range(1, len(arr)):
                if (arr[i] < arr[i-1]):
                        return False
        return True

def getTime(start, end):
        time = end - start
        return round((time / 1000))
        #You may be wondering, why have I not included a unit of time?
        #This sould return millis, but from what I can tell, this is actually tenths of a milli
        #Time calculations may be machine dependent. Idk.


def capture(name, time):
        global CAPTURES
        CAPTURES.append((name, COMPARES, time)) #appending a tuple of the sort, number of COMPARES, time passed, and verification 

def doSort(name, unSortarr, veri = False): #if veri is on, verify the sort works, instead of checking performance


        #Deep copy needs to be used here.
        #Each sort runs on a copy of the unsorted array. 
        #Without deep copy, each sort would modify the same array.
        arr = copy.deepcopy(unSortarr)

        #reset  
        reset()     
        global SORTS
        global TIME
        #do sort
        sortedArr = []
        if name == SORTS[0]:
                if veri:
                        return verify(bubbleSort(arr))

                start = time.perf_counter_ns()
                bubbleSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        if name == SORTS[1]:
                if veri:
                        return verify(selectionSort(arr))

                start = time.perf_counter_ns()
                selectionSort(arr) 
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))

                return
        if name == SORTS[2]:
                if veri:
                        return verify(insertionSort(arr))

                start = time.perf_counter_ns()
                insertionSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        if name == SORTS[3]:
                if veri:
                        return verify(shellSort(arr))

                start = time.perf_counter_ns()
                shellSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        if name == SORTS[4]:
                if veri:
                        return verify(mergeSort(arr))

                start = time.perf_counter_ns()
                mergeSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return

        if name == SORTS[5]:
                if veri:
                        return verify(heapSort(arr))

                start = time.perf_counter_ns()
                heapSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        if name == SORTS[6]:
                if veri:
                        return verify(quickSort(arr))

                start = time.perf_counter_ns()
                quickSort(arr)
                end = time.perf_counter_ns()
                capture(name, getTime(start, end))
                return
        else:   
                print()
                print(name, "Sort is not implemented.")
                print("Implemented sorts:", end = " ")
                for i in SORTS:
                        print("\"" + i + "\"", end = " ")
                print("\n")
                return


def sortComparator(arr, sorts = [], unsortedPrint = True):
        #the sorts parameter can be used to omit sorts, such as bubble sort on a large list
        global CAPTURES

        if sorts == []:
                global SORTS
                sorts = SORTS

        CAPTURES = []

        for sort in sorts: #a deep copy is used
                doSort(sort, arr)

        markdown_table =tabulate.tabulate(CAPTURES, ["Sort", "Compares", "Time"], tablefmt="pipe", stralign="left")
        return (markdown_table)


#AUXILARY FUNCTIONS

def partition(arr, low, high):

    pivot = arr[low]
    i = low - 1
    j = high + 1

    while (True):

        # Find leftmost item greater than
        # or equal to pivot
        i += 1
        while (arr[i] < pivot):
                i += 1
                compare()

        # Find rightmost item smaller than
        # or equal to pivot
        j -= 1
        while (arr[j] > pivot):
                j -= 1
                compare()

        # If two pointers met.
        if (i >= j):
            return j

        temp = arr[i]
        arr[i] = arr[j]
        arr[j] = temp


def heapify(arr, n, i):
    
    # Initialize largest as root
    largest = i
    # left child index = 2*i + 1
    left = 2 * i + 1
    # right child index = 2*i + 2
    right = 2 * i + 2

    if left < n and arr[left] > arr[largest]:
        largest = left

    if right < n and arr[right] > arr[largest]:
        largest = right

    # If largest is not root
    if largest != i:

        #swap
        temp = arr[i] 
        arr[i] = arr[largest]
        arr[largest] = temp

        # Recursively heapify all subheaps
        heapify(arr, n, largest)
    compare()
    return arr


#s, w, and e; pointers to the start, middle, and end indices on an array, to partition the array in place 
def merge(arr, s, m, e):
    merge = []
    left = s
    right = m

    #merging
    #print("subarray:", arr)
    #print ("left:", arr[left:m], "right:", arr[right:e])
    while left < m and right < e:
        compare()
        if arr[left] < arr[right]:
            merge.append(arr[left])
            left = left + 1
            continue
        if arr[right] < arr[left]:
            merge.append(arr[right])
            right = right + 1
            continue
        if arr[left] == arr[right]:
            merge.append(arr[left])
            merge.append(arr[right])
            left = left + 1
            right = right + 1

    #add any leftovers to merge list
    if left == m:
        while right < e:
            merge.append(arr[right])
            right = right + 1
    if right == e:
        while left < m:
            merge.append(arr[left])
            left = left + 1


    #write merge to array
    x = 0
    while (s + x) < e:
        arr[s + x] = merge[x]
        x = x + 1
    return arr #BEHOLD! THE ENTIRE ARRAY WILL BE RETURNED IN FULL!

#SORTS

def shellSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        n = len(arr)
        gap = n // 2
        while gap > 0:
                #insertion sort, on a gap sized to (n - gap)
                for i in range (gap, n):
                        temp = arr[i]
                        j = i

                        while j >= gap and arr[j - gap] > temp:
                                arr[j] = arr[j - gap]
                                j = j - gap          
                        arr[j] = temp
                        compare()
                        
                gap = gap // 2
        return arr
 
def heapSort(arr):

    #The key here is that every unsorted value will eventually be the root (index 0), and then get sorted
    #That is why the max is used. This took me several hours to understand because no tutorial bothers to explain that.
    n = len(arr)

    # Build heap

    halfwayPoint = (n // 2 - 1)
    for i in range(halfwayPoint, -1, -1):
        arr = heapify(arr, n, i)
        

    for i in range(n - 1, 0, -1):
        # Move current root to end
        temp = arr[0]
        arr[0] = arr[i]
        arr[i] = temp
        compare()

        # Call max heapify on the reduced heap
        heapify(arr, i, 0)
    return arr


def mergeSort(arr, s = 0, e = -1):
    if e == -1: #defaults to sorting the entire array
        e = len(arr)
   
    #base cases
    if e - s < 2: #if array is too small to require any sorting 
        return arr
    if e - s == 2 and arr[s] > arr[s + 1]: #if array is of two items, swap as needed
        t = arr[s]
        arr[s] = arr[s+1]
        arr[s+1] = t
        compare()
        return arr

    #get the middle, dividing into left and right
    m = (s + e) // 2 

    arr = mergeSort(arr, s, m) #sort left
    arr = mergeSort(arr, m, e) #sort right
    arr = merge(arr, s, m, e) #merges left and right as a sorted array
    
    return arr



def bubbleSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        
        #given arr is an array
        n = len(arr)
        i = 0
        x = 1

        while(x < (n + 1)):
                while(i < n - x):
                        swapCheck(arr, i, i+1)
                        i = i +1
                i =0
                x = x+1
        return arr

def selectionSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        maxIndex = len(arr) - 1
        maxValue = -1

        while(maxIndex > 0):
                i = 0
                indexUnsortedMax = -1
                #get max unsorted value
                while (i <= maxIndex):  #this inequality was diabolical. It took an hour to notice I had written '<', not '<='. 
                        compare()
                        if arr[i] > maxValue:
                                maxValue = arr[i]
                                indexUnsortedMax = i
                        i = i + 1
                if indexUnsortedMax > - 1:
                        doSwap(arr, maxIndex, indexUnsortedMax)
                        maxValue = -1
                i = 0
                maxIndex = maxIndex - 1
        return arr
                
def insertionSort(arr): 
        if len(arr) < 2: #already sorted case
                return arr
        for i in range (0, len(arr) -1):
                j = i + 1
                while j > 0:
                        swapCheck(arr, j-1, j)
                        j = j - 1
        return arr

def quickSort(arr, low = 0, high = -1):
        #whole array by default
        if high == -1:
                high = len(arr) -1

        if (low < high):
                compare()
                partitionIndex = partition(arr, low, high)
                #recursively sort either side of the partition
                quickSort(arr, low, partitionIndex)
                quickSort(arr, partitionIndex + 1, high)
        return arr


#SWAP FUNCTIONS

#this is a conditional swap, used to sort elements
def swapCheck(arr, a, b):
        if (arr[a] > arr[b]):
                arr = doSwap(arr, a, b)
        compare()
        return arr

#this is an unconditional swap, used to count COMPARES
def doSwap(arr, a, b):
        temp = arr[a]
        arr[a] = arr[b]
        arr[b] = temp
        compare()
        return arr

#ARRAY GENERATOR FUNCTIONS

def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                out.append(a[r])
                a.remove(a[r])
        return out

def test(n):
        global SORTS
        global VERIFIED
        
        if not VERIFIED:
                print("Verifying Sorts")

                for sort in SORTS:
                        if not doSort(sort, revArr(25), True):
                                print (sort, "Sort falied. Debug is needed.")
                                return
                VERIFIED = True
                print("Verified!\n")

        print("Sorts on arrays of size " + str(n) +":")
        print("Sorted, Reversed, and Shuffled")
        print()
        print(sortComparator(ordArr(n)))
        print()
        print(sortComparator(revArr(n)))
        print()
        print(sortComparator(shufArr(n)))
        print()


#MAIN
if __name__ == '__main__':
        test(150)

        